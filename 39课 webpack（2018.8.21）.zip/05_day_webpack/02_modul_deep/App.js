var App  = {
	template:`
		<div>我是一个入口组件</div>
	`
};

export default App;