import './main.less'
console.log('1111111');

const app = '张三';

let a = 15;
console.log(a);

var obj = ()=>{

};

// new Promise();