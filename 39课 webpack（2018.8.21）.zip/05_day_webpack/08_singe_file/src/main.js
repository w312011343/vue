import Vue from 'vue';
import App from './App.vue'
// 组件  .vue



new Vue({
	el:'#app',
	render:c=>c(App)
	// components:{
	// 	App
	// },
	// template:`<App />`
});