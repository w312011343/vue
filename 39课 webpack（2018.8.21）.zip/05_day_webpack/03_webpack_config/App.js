var App  = {
	template:`
		<div>我是一个入口组件</div>
	`
};
console.log(222);

export default App;