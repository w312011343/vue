<template>
	<div class="index">我是首页组件</div>
</template>

<script>
export default {

  name: 'Index',

  data() {
    return {

    };
  },
};
</script>

<style>
</style>
