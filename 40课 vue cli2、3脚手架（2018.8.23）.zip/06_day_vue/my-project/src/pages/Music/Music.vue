<template>
	<div class="music">我是音乐组件</div>
</template>

<script>
export default {

  name: 'Music',

  data() {
    return {

    };
  },
};
</script>

<style lang="css" scoped>
</style>
